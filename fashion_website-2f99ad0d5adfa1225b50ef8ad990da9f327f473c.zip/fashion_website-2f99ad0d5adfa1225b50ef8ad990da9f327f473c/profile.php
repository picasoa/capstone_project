<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="CSS/profile.css">
	<script type="text/javascript" src="scripts/jq.js"></script>
	<script type="text/javascript">


</script>
</head>
<body>

<div id="main">
	<div class="bar">
	<div class="icon menu"></div>
	
	</div>
	<div class="search">s</div>
	<div class="menu_box">
		<div class="social-bar">
			<ul>
				<li><a href="#">a</a></li>
				<li><a href="#">a</a></li>
				<li><a href="#">a</a></li>
				<li><a href="#">a</a></li>
				<li><a href="#">a</a></li>
			</ul>
		</div>
		<h1>VERSUGO</h1>
		<ul>
			<li><a href="#">All Post</a></li>
			<li><a href="#">Blah</a></li>
			<li><a href="#">Blaha</a></li>
			<li><a href="#">Bsldjaslk</a></li>
			<li><a href="#">Saldja</a></li>
			<li><a href="#">Sakdhsakj</a></li>
		</ul>
	</div>
	<div class="cover_box">
		<div class="cover_pic">
			<h1>VERSUGO</h1>
			<q>
				Fashion is like eating, you shouldn't stick to the same menu
			</q>
		</div>
		<img src="">
	</div>

	<div class="profile_data">
		<div class="profile_pic_box">
			<img src="images/coverpic.jpg">
		</div>
		<div class="profile_info">
			<div class="heading"><span style="font-size: .3em;">About</span> Me</div>
			<div class="info">
				<ul rel="1">
					<li>Hamu Dhillon</li>
					<li>Hamu.dhillon@gmail.com</li>
					<li>8427314684</li>
				</ul>
				<div class="more_info" rel="2">
					<h2>Hello</h2>
				</div>
			</div>
			<div class="next">></div>
			<div class="back"><</div>

		</div>
		<br>
		<div style="clear: both;"></div>

		<div class="posts">

		<div class="post_box"><a href="#">
				 <div class="post_img">
				 	<img src="images/post.jpg">
				 </div>
				 <div class="post_type">
					<a href="#"><h3>Fashion</h3></a>		
				 </div>
				<a href="#"> <div class="post_title">
				 	Spring Outerwear: The Low to High Priced Coat and Jacket Edit
				 </div></a>
				 <a href="#"><div class="post_info">
				 	Spring has sprung and the stores are full of lightweight jackets ready for the blue skies that are just around the corner – here are my faves! 

				 </div></a>
			</a>	
		</div>
		
		<div class="post_box"><a href="#">
				 <div class="post_img">
				 	<img src="images/post.jpg">
				 </div>
				 <div class="post_type">
					<a href="#"><h3>Fashion</h3></a>		
				 </div>
				<a href="#"> <div class="post_title">
				 	Spring Outerwear: The Low to High Priced Coat and Jacket Edit
				 </div></a>
				 <a href="#"><div class="post_info">
				 	Spring has sprung and the stores are full of lightweight jackets ready for the blue skies that are just around the corner – here are my faves! 
				 	
				 </div></a>
			</a>	
		</div>

		<div class="post_box"><a href="#">
				 <div class="post_img">
				 	<img src="images/post.jpg">
				 </div>
				 <div class="post_type">
					<a href="#"><h3>Fashion</h3></a>		
				 </div>
				<a href="#"> <div class="post_title">
				 	Spring Outerwear: The Low to High Priced Coat and Jacket Edit
				 </div></a>
				 <a href="#"><div class="post_info">
				 	Spring has sprung and the stores are full of lightweight jackets ready for the blue skies that are just around the corner – here are my faves! 
				 	
				 </div></a>
			</a>	
		</div>


		<div class="post_box"><a href="#">
				 <div class="post_img">
				 	<img src="images/post.jpg">
				 </div>
				 <div class="post_type">
					<a href="#"><h3>Fashion</h3></a>		
				 </div>
				<a href="#"> <div class="post_title">
				 	Spring Outerwear: The Low to High Priced Coat and Jacket Edit
				 </div></a>
				 <a href="#"><div class="post_info">
				 	Spring has sprung and the stores are full of lightweight jackets ready for the blue skies that are just around the corner – here are my faves! 
				 	
				 </div></a>
			</a>	
		</div>
		</div>	
	</div>
	
	

<div style="clear: both;"></div>
</div>




<script type="text/javascript" src="scripts/profile.js"></script>


</body>
</html>